#ifndef _DELAY_H
#define _DELAY_H

void delay_us(uint t);
void delay_ms(uint t);
void delay(int t);

#endif